//2115 ��ä��
#include <iostream>
using namespace std;

int main() {
	int num, num1, i, j;
	cout << "����1 �Է� : ";
	cin >> num;
	cout << "����2 �Է� : ";
	cin >> num1;

	
	for (i = 1; i <= 9; i++) {
		}
	for (j = 1; j <= 9; j++) {
		cout << num << "*" << j << "=" << num * j << endl;
	}

	for (i = 1; i <= 9; i++) {
	}
	for (j = 1; j <= 9; j++) {
		cout << num1-1 << "*" << j << "=" << (num1-1)*j << endl;
	}
	for (i = 1; i <= 9; i++) {
	}
	for (j = 1; j <= 9; j++) {
		cout << num1 << "*" << j << "=" << num1 * j << endl;
	}



}